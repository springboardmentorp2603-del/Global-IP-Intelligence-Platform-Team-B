package com.ipplatform.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
